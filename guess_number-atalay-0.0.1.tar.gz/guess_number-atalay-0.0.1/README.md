# guess number

Guess the number game for given range

### Prerequisites

Python => 3.6

### Installing

Install package by using pip

```
pip install guess_number-atalay
```

## Authors

* **Atalay Denknalbant** - *calculus_formulas* 


## License

This project is licensed under the GNU GENERAL PUBLIC LICENSE - see the [LICENSE](LICENSE) file for details